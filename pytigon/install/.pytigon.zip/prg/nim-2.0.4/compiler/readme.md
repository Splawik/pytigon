## Nim Compiler

- This directory contains the Nim compiler written in Nim.
- Note that this code has been translated from a bootstrapping version written in Pascal.
- So the code is **not** a poster child of good Nim code.

See [Internals of the Nim Compiler](https://nim-lang.github.io/Nim/intern.html) for more information.
