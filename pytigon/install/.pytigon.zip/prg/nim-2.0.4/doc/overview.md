=============================
Nim Documentation Overview
=============================

:Author: Andreas Rumpf
:Version: |nimversion|

.. include:: docs.md

